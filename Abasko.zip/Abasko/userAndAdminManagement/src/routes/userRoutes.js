const express = require('express');
const authController = require('../controllers/authController');
const userController = require('../controllers/userController');
const { authMiddleware, adminMiddleware } = require('../middlewares/authMiddleware');

const router = express.Router();

// Auth Routes
router.post('/register', authController.register);
router.post('/login', authController.login);

// Admin Routes
router.get('/users', authMiddleware, adminMiddleware, userController.getAllUsers);
router.delete('/users/:id', authMiddleware, adminMiddleware, userController.deleteUser);

// User/Admin Routes
router.get('/profile', authMiddleware, userController.getProfile);

module.exports = router;

const bcrypt = require('bcrypt');
const userQuery = require('../queries/userQuery');

exports.registerUser = async (username, password, role) => {
    const hashedPassword = await bcrypt.hash(password, 10);
    return await userQuery.createUser({ username, password: hashedPassword, role });
};

exports.validateUser = async (username, password) => {
    const user = await userQuery.findUserByUsername(username);
    if (!user) {
        return null;
    }
    const isMatch = await bcrypt.compare(password, user.password);
    return isMatch ? user : null;
};

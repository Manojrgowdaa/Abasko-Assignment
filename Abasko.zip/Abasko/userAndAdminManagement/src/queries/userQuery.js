const User = require('../models/userModel');

exports.createUser = async (data) => {
    return await User.create(data);
};

exports.findUserByUsername = async (username) => {
    return await User.findOne({ username });
};

exports.findAllUsers = async () => {
    return await User.find({});
};

exports.deleteUserById = async (id) => {
    return await User.findByIdAndDelete(id);
};

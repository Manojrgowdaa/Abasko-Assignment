const userService = require('../services/userService');
const jwt = require('jsonwebtoken');


exports.register = async (req, res) => {
    const { username, password, role } = req.body;
    try {
        const user = await userService.registerUser(username, password, role);
        res.status(201).json({ id: user._id, username: user.username, role: user.role });
    } catch (error) {
        res.status(400).json({ error: 'Error registering user' });
    }
};
exports.login = async (req, res) => {
    const { username, password } = req.body;
    try {
        const user = await userService.validateUser(username, password);
        if (!user) {
            return res.status(400).json({ error: 'Invalid credentials' });
        }
        
        const token = jwt.sign({ id: user._id, role: user.role }, JWT_SECRET="supersecure", { expiresIn: '1h' });
        res.json({ token });
    } catch (error) {
        
        res.status(500).json({ error: 'Login failed' });
    }
};

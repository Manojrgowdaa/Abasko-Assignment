const userQuery = require('../queries/userQuery');

exports.getAllUsers = async (req, res) => {
    try {
        const users = await userQuery.findAllUsers();
        res.json(users);
    } catch (error) {
        res.status(500).json({ error: 'Error retrieving users' });
    }
};

exports.getProfile = async (req, res) => {
    res.json({ id: req.user.id, username: req.user.username, role: req.user.role });
};

exports.deleteUser = async (req, res) => {
    try {
        await userQuery.deleteUserById(req.params.id);
        res.json({ message: 'User deleted' });
    } catch (error) {
        res.status(500).json({ error: 'Error deleting user' });
    }
};
